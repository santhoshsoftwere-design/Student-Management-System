public class Student {

    private int id;
    private String name;
    private int age;
    private int javaMark;
    private int pythonMark;
    private int dbMark;

    public Student(int id, String name, int age,
                   int javaMark, int pythonMark, int dbMark) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.javaMark = javaMark;
        this.pythonMark = pythonMark;
        this.dbMark = dbMark;
    }

    public int getId() {
        return id;
    }

    public int getTotal() {
        return javaMark + pythonMark + dbMark;
    }

    public double getAverage() {
        return getTotal() / 3.0;
    }

    public String getGrade() {
        double avg = getAverage();

        if (avg >= 90)
            return "A+";
        else if (avg >= 80)
            return "A";
        else if (avg >= 70)
            return "B";
        else if (avg >= 60)
            return "C";
        else
            return "F";
    }

    public String getResult() {
        if (javaMark >= 35 &&
            pythonMark >= 35 &&
            dbMark >= 35)
            return "PASS";

        return "FAIL";
    }

    @Override
    public String toString() {

        return "\n----------------------" +
               "\nID      : " + id +
               "\nName    : " + name +
               "\nAge     : " + age +
               "\nJava    : " + javaMark +
               "\nPython  : " + pythonMark +
               "\nDBMS    : " + dbMark +
               "\nTotal   : " + getTotal() +
               "\nAverage : " + getAverage() +
               "\nGrade   : " + getGrade() +
               "\nResult  : " + getResult();
    }
}