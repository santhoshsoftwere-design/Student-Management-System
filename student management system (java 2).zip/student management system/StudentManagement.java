import java.util.ArrayList;
import java.util.Scanner;

public class StudentManagement {

    static ArrayList<Student> students = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        login();

        while (true) {

            System.out.println("\n===== STUDENT MANAGEMENT SYSTEM =====");
            System.out.println("1. Add Student");
            System.out.println("2. View Students");
            System.out.println("3. Search Student");
            System.out.println("4. Report");
            System.out.println("5. Exit");

            System.out.print("Enter Choice: ");
            int choice = sc.nextInt();

            switch (choice) {

                case 1:
                    addStudent();
                    break;

                case 2:
                    viewStudents();
                    break;

                case 3:
                    searchStudent();
                    break;

                case 4:
                    generateReport();
                    break;

                case 5:
                    System.out.println("Program Closed");
                    System.exit(0);

                default:
                    System.out.println("Invalid Choice");
            }
        }
    }

    static void login() {

        System.out.println("===== ADMIN LOGIN =====");

        System.out.print("Username: ");
        String username = sc.next();

        System.out.print("Password: ");
        String password = sc.next();

        if (username.equals("admin")
                && password.equals("1234")) {

            System.out.println("Login Successful");
        } else {

            System.out.println("Invalid Login");
            System.exit(0);
        }
    }

    static void addStudent() {

        System.out.print("ID: ");
        int id = sc.nextInt();

        sc.nextLine();

        System.out.print("Name: ");
        String name = sc.nextLine();

        System.out.print("Age: ");
        int age = sc.nextInt();

        System.out.print("Java Mark: ");
        int java = sc.nextInt();

        System.out.print("Python Mark: ");
        int python = sc.nextInt();

        System.out.print("DBMS Mark: ");
        int dbms = sc.nextInt();

        students.add(
                new Student(
                        id,
                        name,
                        age,
                        java,
                        python,
                        dbms));

        System.out.println("Student Added Successfully");
    }

    static void viewStudents() {

        if (students.isEmpty()) {
            System.out.println("No Students Available");
            return;
        }

        for (Student s : students) {
            System.out.println(s);
        }
    }

    static void searchStudent() {

        System.out.print("Enter Student ID: ");
        int id = sc.nextInt();

        for (Student s : students) {

            if (s.getId() == id) {
                System.out.println(s);
                return;
            }
        }

        System.out.println("Student Not Found");
    }

    static void generateReport() {

        int pass = 0;
        int fail = 0;

        for (Student s : students) {

            if (s.getResult().equals("PASS"))
                pass++;
            else
                fail++;
        }

        System.out.println("\n===== REPORT =====");
        System.out.println("Total Students : " + students.size());
        System.out.println("Pass Students  : " + pass);
        System.out.println("Fail Students  : " + fail);
    }
}